
import React, { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import CourseExplorer from './components/CourseExplorer';
import EnrollmentModal from './components/EnrollmentModal';
import Footer from './components/Footer';
import LoginPage from './components/LoginPage';
import SignUpPage from './components/SignUpPage';

type View = 'landing' | 'login' | 'signup';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>('landing');
  const [isEnrollModalOpen, setIsEnrollModalOpen] = useState(false);

  const toggleModal = () => setIsEnrollModalOpen(!isEnrollModalOpen);
  
  const navigateTo = (view: View) => {
    setCurrentView(view);
    setIsEnrollModalOpen(false);
    window.scrollTo(0, 0);
  };

  if (currentView === 'login') {
    return <LoginPage onBack={() => navigateTo('landing')} onSignUp={() => navigateTo('signup')} />;
  }

  if (currentView === 'signup') {
    return <SignUpPage onBack={() => navigateTo('landing')} onLogin={() => navigateTo('login')} />;
  }

  return (
    <div className="min-h-screen flex flex-col animate-in fade-in duration-500">
      <Header 
        onEnrollClick={() => navigateTo('signup')} 
        onLoginClick={() => navigateTo('login')}
        onHomeClick={() => navigateTo('landing')}
      />
      
      <main className="flex-grow">
        <Hero onEnrollClick={() => navigateTo('signup')} />
        
        <section id="courses" className="py-20 bg-white">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-4 text-indigo-900">
              Discover Our "Enjoying" Courses
            </h2>
            <p className="text-center text-slate-600 mb-12 max-w-2xl mx-auto">
              Master the essentials of modern web development with Soli's curated curriculum. 
              We make software engineering fun and accessible!
            </p>
            <CourseExplorer />
          </div>
        </section>
      </main>

      <Footer />

      {isEnrollModalOpen && <EnrollmentModal onClose={toggleModal} />}
    </div>
  );
};

export default App;
