
export interface CourseDetail {
  id: string;
  title: string;
  fullName: string;
  meaning: string;
  tutorial: string;
  exampleCode: string;
  externalLink: string;
  icon: string;
  color: string;
}

export type Specialization = 'Fullstack' | 'Backend' | 'Frontend' | 'HTML' | 'CSS' | 'JavaScript';

export type PaymentMethodType = 'Telebirr' | 'PayPal' | 'MasterCard' | 'EthiopianBank';

export interface EnrollmentData {
  fullName: string;
  email: string;
  password: string;
  age: number;
  specialization: Specialization;
  paymentMethod?: PaymentMethodType;
  bankName?: string;
}
