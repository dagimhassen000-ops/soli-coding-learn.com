
import React, { useState, useRef, useEffect } from 'react';

interface HeaderProps {
  onEnrollClick: () => void;
  onLoginClick: () => void;
  onHomeClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ onEnrollClick, onLoginClick, onHomeClick }) => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleExplorePlayground = () => {
    setIsDropdownOpen(false);
    onHomeClick();
    setTimeout(() => {
      const element = document.getElementById('courses');
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };

  const learningResources = [
    {
      title: 'HTML',
      icon: 'fab fa-html5 text-orange-500',
      links: [
        { name: 'W3Schools HTML', url: 'https://www.w3schools.com/html/' },
        { name: 'MDN Web Docs', url: 'https://developer.mozilla.org/en-US/docs/Web/HTML' }
      ]
    },
    {
      title: 'CSS',
      icon: 'fab fa-css3-alt text-blue-500',
      links: [
        { name: 'CSS-Tricks Guide', url: 'https://css-tricks.com/' },
        { name: 'Learn Flexbox', url: 'https://flexboxfroggy.com/' }
      ]
    },
    {
      title: 'JavaScript',
      icon: 'fab fa-js text-yellow-500',
      links: [
        { name: 'JavaScript.info', url: 'https://javascript.info/' },
        { name: 'JS Tutorial', url: 'https://www.w3schools.com/js/' }
      ]
    },
    {
      title: 'Python',
      icon: 'fab fa-python text-indigo-500',
      links: [
        { name: 'Python.org', url: 'https://www.python.org/' },
        { name: 'Real Python', url: 'https://realpython.com/' }
      ]
    }
  ];

  return (
    <header className="sticky top-0 z-50 w-full bg-white/95 backdrop-blur-md border-b border-slate-100 shadow-sm">
      <div className="container mx-auto px-4 h-20 flex items-center justify-between">
        {/* Brand Logo */}
        <button 
          onClick={onHomeClick}
          className="flex items-center space-x-2 hover:opacity-80 transition-opacity"
        >
          <div className="w-10 h-10 bg-indigo-500 rounded-xl flex items-center justify-center text-white text-2xl font-bold shadow-lg shadow-indigo-100 border-2 border-white/20">
            S
          </div>
          <span className="text-xl font-bold tracking-tight text-indigo-900">
            Soli<span className="text-indigo-500 font-medium">Software</span>
          </span>
        </button>

        {/* Navigation - Ordered specifically: Home, Courses, Contact */}
        <nav className="hidden md:flex items-center space-x-10 relative">
          <button 
            onClick={onHomeClick} 
            className="text-slate-600 hover:text-indigo-600 transition-colors font-bold text-sm tracking-wide"
          >
            HOME
          </button>

          <div className="relative" ref={dropdownRef}>
            <button 
              onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              onMouseEnter={() => setIsDropdownOpen(true)}
              className={`flex items-center gap-1.5 font-bold text-sm tracking-wide transition-colors ${isDropdownOpen ? 'text-indigo-600' : 'text-slate-600 hover:text-indigo-600'}`}
            >
              COURSES
              <i className={`fas fa-chevron-down text-[10px] transition-transform duration-300 ${isDropdownOpen ? 'rotate-180' : ''}`}></i>
            </button>

            {isDropdownOpen && (
              <div 
                className="absolute top-full left-1/2 -translate-x-1/2 mt-4 w-[640px] bg-white rounded-[2rem] shadow-2xl border border-slate-100 p-8 animate-in fade-in slide-in-from-top-2 duration-300 grid grid-cols-2 gap-8"
                onMouseLeave={() => setIsDropdownOpen(false)}
              >
                <div className="col-span-2 pb-4 border-b border-slate-50">
                  <h4 className="text-indigo-900 font-extrabold text-xl">Enjoy Software Resources</h4>
                  <p className="text-slate-400 text-sm">Pick a language and start your journey with Soli</p>
                </div>
                
                {learningResources.map((resource, idx) => (
                  <div key={idx} className="space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center border border-slate-100">
                        <i className={`${resource.icon} text-lg`}></i>
                      </div>
                      <span className="font-bold text-slate-800">{resource.title}</span>
                    </div>
                    <ul className="space-y-2.5">
                      {resource.links.map((link, lIdx) => (
                        <li key={lIdx}>
                          <a 
                            href={link.url} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-sm text-slate-500 hover:text-indigo-600 hover:translate-x-1 transition-all flex items-center gap-2 group"
                          >
                            <i className="fas fa-circle text-[4px] text-indigo-200 group-hover:text-indigo-500 transition-colors"></i>
                            {link.name}
                          </a>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}

                <div className="col-span-2 pt-4 border-t border-slate-50">
                  <button 
                    onClick={handleExplorePlayground}
                    className="block w-full text-center py-4 bg-indigo-50 text-indigo-600 rounded-2xl font-bold hover:bg-indigo-600 hover:text-white transition-all transform hover:-translate-y-1"
                  >
                    🚀 Explore Interactive Playground
                  </button>
                </div>
              </div>
            )}
          </div>

          <a 
            href="https://www.instagram.com/solana6924" 
            target="_blank" 
            rel="noopener noreferrer" 
            className="text-slate-600 hover:text-indigo-600 transition-colors font-bold text-sm tracking-wide"
          >
            CONTACT
          </a>
        </nav>

        {/* Action Buttons */}
        <div className="flex items-center gap-3">
          <button 
            onClick={onLoginClick}
            className="text-indigo-600 font-bold hover:text-indigo-700 px-5 py-2.5 rounded-xl transition-all hover:bg-indigo-50"
          >
            Login
          </button>
          <button 
            onClick={onEnrollClick}
            className="bg-indigo-600 text-white px-7 py-3 rounded-full font-bold hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-200 active:scale-95 border-2 border-white/10"
          >
            Enroll Now
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
