
import React from 'react';

interface HeroProps {
  onEnrollClick: () => void;
}

const Hero: React.FC<HeroProps> = ({ onEnrollClick }) => {
  return (
    <section className="relative pt-16 pb-24 overflow-hidden bg-gradient-to-br from-indigo-50 via-slate-50 to-pink-50">
      {/* Decorative blobs */}
      <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 bg-indigo-200 rounded-full blur-3xl opacity-30"></div>
      <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-96 h-96 bg-pink-200 rounded-full blur-3xl opacity-30"></div>

      <div className="container mx-auto px-4 relative">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-12">
          <div className="flex-1 text-center lg:text-left">
            <div className="inline-block px-4 py-1.5 mb-6 bg-pink-100 text-pink-600 rounded-full font-bold text-sm uppercase tracking-wider animate-bounce">
              🎉 75% OFF Special Offer!
            </div>
            <h1 className="text-5xl md:text-7xl font-extrabold text-indigo-950 leading-tight mb-6">
              Learn to <span className="text-indigo-600">Enjoy</span> Software with Soli
            </h1>
            <p className="text-xl text-slate-600 mb-8 max-w-xl">
              Transform your career by mastering the world's most powerful programming languages. Join Solana's exclusive course and start building your future today.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <button 
                onClick={onEnrollClick}
                className="bg-indigo-600 text-white px-8 py-4 rounded-2xl font-bold text-lg hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-200 hover:-translate-y-1 active:scale-95"
              >
                Enroll in SoliSoft Now
              </button>
              <a 
                href="https://www.instagram.com/solana6924" 
                target="_blank" 
                rel="noopener noreferrer"
                className="bg-white text-indigo-600 border-2 border-indigo-100 px-8 py-4 rounded-2xl font-bold text-lg hover:bg-indigo-50 transition-all flex items-center justify-center gap-2"
              >
                <i className="fab fa-instagram text-xl"></i>
                Follow Soli
              </a>
            </div>
            
            <div className="mt-12 flex items-center justify-center lg:justify-start gap-6 text-slate-500">
              <div className="flex flex-col items-center lg:items-start">
                <span className="text-2xl font-bold text-indigo-900">5,000+</span>
                <span className="text-sm">Happy Students</span>
              </div>
              <div className="w-px h-10 bg-slate-300"></div>
              <div className="flex flex-col items-center lg:items-start">
                <span className="text-2xl font-bold text-indigo-900">4.9/5</span>
                <span className="text-sm">Course Rating</span>
              </div>
            </div>
          </div>

          <div className="flex-1 relative">
            <div className="relative z-10 w-full max-w-lg mx-auto aspect-square rounded-3xl overflow-hidden shadow-2xl shadow-indigo-100 rotate-2 border-8 border-white">
              <img 
                src="https://picsum.photos/seed/soli/800/800" 
                alt="Software Engineering" 
                className="w-full h-full object-cover"
              />
            </div>
            {/* Absolute element overlays */}
            <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-2xl shadow-lg border border-slate-100 animate-pulse z-20 hidden sm:block">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                  <i className="fas fa-check text-green-600"></i>
                </div>
                <div>
                  <p className="font-bold text-slate-800">Job Ready Skills</p>
                  <p className="text-xs text-slate-500">Industry standard curriculum</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
