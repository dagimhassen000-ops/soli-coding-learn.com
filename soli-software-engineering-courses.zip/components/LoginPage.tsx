
import React, { useState } from 'react';

interface LoginPageProps {
  onBack: () => void;
  onSignUp: () => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onBack, onSignUp }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Simulate auth
    setTimeout(() => {
      setLoading(false);
      alert("Welcome back to Soli Software Enjoying Course!");
      onBack();
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="container mx-auto px-4 py-8">
        <button 
          onClick={onBack}
          className="flex items-center gap-2 text-indigo-600 font-bold hover:translate-x-1 transition-transform mb-12"
        >
          <i className="fas fa-arrow-left"></i>
          Back to Home
        </button>

        <div className="max-w-md mx-auto">
          <div className="text-center mb-10">
            <div className="w-16 h-16 bg-indigo-500 rounded-2xl flex items-center justify-center text-white text-4xl font-bold mx-auto mb-6 shadow-xl shadow-indigo-100">
              S
            </div>
            <h1 className="text-4xl font-extrabold text-indigo-950 mb-2">Welcome Back</h1>
            <p className="text-slate-500 font-medium">Log in to continue your software enjoyment</p>
          </div>

          <div className="bg-white p-10 rounded-[2.5rem] shadow-2xl shadow-slate-200 border border-slate-100">
            <form onSubmit={handleLogin} className="space-y-6">
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2 ml-1">Email Address</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">
                    <i className="fas fa-envelope"></i>
                  </span>
                  <input 
                    required
                    type="email" 
                    placeholder="student@example.com"
                    className="w-full pl-12 pr-4 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-inner"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2 ml-1 flex justify-between">
                  Password
                  <a href="#" className="text-indigo-500 font-medium hover:underline">Forgot?</a>
                </label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">
                    <i className="fas fa-lock"></i>
                  </span>
                  <input 
                    required
                    type="password" 
                    placeholder="••••••••"
                    className="w-full pl-12 pr-4 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-inner"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 px-1">
                <input type="checkbox" id="remember" className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500" />
                <label htmlFor="remember" className="text-sm text-slate-500 font-medium cursor-pointer">Keep me logged in</label>
              </div>

              <button 
                type="submit" 
                disabled={loading}
                className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-bold text-lg hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100 flex items-center justify-center gap-3 disabled:opacity-70 active:scale-[0.98]"
              >
                {loading ? (
                  <>
                    <i className="fas fa-spinner fa-spin"></i> Signing in...
                  </>
                ) : (
                  <>Sign In</>
                )}
              </button>
            </form>

            <div className="mt-8 text-center">
              <p className="text-slate-500 text-sm">
                Don't have an account? {' '}
                <button 
                  onClick={onSignUp}
                  className="text-indigo-600 font-bold hover:underline"
                >
                  Enroll Now
                </button>
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-auto py-8 text-center text-slate-400 text-sm">
        © {new Date().getFullYear()} Soli Software Enjoying Course
      </div>
    </div>
  );
};

export default LoginPage;
