
import React, { useState } from 'react';
import { CourseDetail } from '../types';

interface ResourceLink {
  label: string;
  url: string;
  provider: string;
}

interface ExtendedCourseDetail extends CourseDetail {
  previewHtml?: string;
  resources: ResourceLink[];
}

const COURSES: ExtendedCourseDetail[] = [
  {
    id: 'html',
    title: 'HTML',
    fullName: 'HyperText Markup Language',
    icon: 'fab fa-html5',
    color: 'text-orange-500 bg-orange-50',
    meaning: 'HTML is the standard markup language used to create the structure of web pages. It is the very first thing every software engineer should enjoy learning!',
    tutorial: 'Start by creating a simple file ending in .html. Use tags like <h1> for big titles and <p> for sentences. It is like building the bones of a beautiful house.',
    exampleCode: `<!DOCTYPE html>
<html>
<body>
  <h1>Hello from Soli!</h1>
  <p>Software Engineering is fun!</p>
</body>
</html>`,
    previewHtml: `<h1 style="color: #6366f1; font-family: sans-serif;">Hello from Soli!</h1><p style="font-family: sans-serif;">Software Engineering is fun!</p>`,
    externalLink: 'https://www.w3schools.com/html/',
    resources: [
      { label: 'W3Schools HTML Tutorial', url: 'https://www.w3schools.com/html/', provider: 'W3Schools' },
      { label: 'MDN Web Docs: HTML', url: 'https://developer.mozilla.org/en-US/docs/Web/HTML', provider: 'Mozilla' },
      { label: 'FreeCodeCamp Responsive Web Design', url: 'https://www.freecodecamp.org/learn/2022/responsive-web-design/', provider: 'FreeCodeCamp' }
    ]
  },
  {
    id: 'css',
    title: 'CSS',
    fullName: 'Cascading Style Sheets',
    icon: 'fab fa-css3-alt',
    color: 'text-blue-500 bg-blue-50',
    meaning: 'CSS is what makes websites look beautiful. It controls the colors, the layouts, and the "Enjoyment" factor of the design.',
    tutorial: 'Link your CSS file to your HTML. Use selectors like "h1" or ".button" to change colors and fonts. Master Flexbox and Grid to make your site responsive!',
    exampleCode: `body {
  background-color: #f0f9ff;
  font-family: 'Quicksand', sans-serif;
}

h1 {
  color: #4f46e5;
  text-align: center;
}`,
    previewHtml: `<div style="background-color: #f0f9ff; padding: 20px; border-radius: 10px; text-align: center; font-family: sans-serif; border: 2px dashed #4f46e5;"><h1 style="color: #4f46e5; margin: 0;">Soli Style</h1></div>`,
    externalLink: 'https://www.w3schools.com/css/',
    resources: [
      { label: 'W3Schools CSS Tutorial', url: 'https://www.w3schools.com/css/', provider: 'W3Schools' },
      { label: 'CSS-Tricks Guides', url: 'https://css-tricks.com/guides/', provider: 'CSS-Tricks' },
      { label: 'Flexbox Froggy Game', url: 'https://flexboxfroggy.com/', provider: 'Codepip' }
    ]
  },
  {
    id: 'js',
    title: 'JavaScript',
    fullName: 'JS Programming',
    icon: 'fab fa-js',
    color: 'text-yellow-500 bg-yellow-50',
    meaning: 'JavaScript is the engine that brings websites to life. It handles clicks, animations, and data processing.',
    tutorial: 'Learn variables (let, const), functions, and how to select elements from your HTML. Practice by making buttons show alerts or changing background colors on the fly.',
    exampleCode: `function saySoliHello() {
  alert("Soli welcomes you to JS!");
  console.log("Enjoy your code!");
}`,
    previewHtml: `<div style="text-align: center; font-family: sans-serif;"><button onclick="alert('Enjoying Software with Soli!')" style="padding: 12px 24px; background: #fbbf24; color: black; border: none; border-radius: 10px; cursor: pointer; font-weight: bold;">Click for JS Action</button></div>`,
    externalLink: 'https://www.javascript.com/',
    resources: [
      { label: 'JavaScript.info Guide', url: 'https://javascript.info/', provider: 'JS.info' },
      { label: 'Eloquent JavaScript Book', url: 'https://eloquentjavascript.net/', provider: 'Marijn Haverbeke' },
      { label: 'Modern JS Tutorial', url: 'https://www.w3schools.com/js/', provider: 'W3Schools' }
    ]
  },
  {
    id: 'py',
    title: 'Python',
    fullName: 'Python Logic',
    icon: 'fab fa-python',
    color: 'text-indigo-500 bg-indigo-50',
    meaning: 'Python is a high-level language known for being easy to read. It is perfect for beginners and data experts alike.',
    tutorial: 'Install Python and use "print()" to see your first output. Move on to Lists, Dictionaries, and Loops. Python makes automation and AI feel like a walk in the park.',
    exampleCode: `def enjoy_software():
    message = "Python is amazing!"
    print(message)

enjoy_software()`,
    previewHtml: `<div style="background: #1e293b; color: #38bdf8; padding: 15px; border-radius: 8px; font-family: monospace;">> python app.py<br/>Python is amazing!</div>`,
    externalLink: 'https://www.python.org/',
    resources: [
      { label: 'Python Official Tutorial', url: 'https://docs.python.org/3/tutorial/', provider: 'Python.org' },
      { label: 'Real Python Articles', url: 'https://realpython.com/', provider: 'Real Python' },
      { label: 'Automate the Boring Stuff', url: 'https://automatetheboringstuff.com/', provider: 'Al Sweigart' }
    ]
  }
];

const CourseExplorer: React.FC = () => {
  const [activeTab, setActiveTab] = useState(COURSES[0].id);
  const activeCourse = COURSES.find(c => c.id === activeTab) || COURSES[0];

  return (
    <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-slate-100">
      {/* Tab Navigation */}
      <div className="flex flex-wrap border-b border-slate-100 bg-slate-50/50">
        {COURSES.map(course => (
          <button
            key={course.id}
            onClick={() => setActiveTab(course.id)}
            className={`flex-1 min-w-[120px] py-6 px-4 flex flex-col items-center gap-2 transition-all duration-300 relative ${
              activeTab === course.id 
                ? 'bg-white text-indigo-600' 
                : 'text-slate-400 hover:text-slate-600 hover:bg-white/50'
            }`}
          >
            <i className={`${course.icon} text-3xl`}></i>
            <span className="font-bold uppercase tracking-widest text-xs mt-1">{course.title}</span>
            {activeTab === course.id && (
              <div className="absolute bottom-0 left-0 w-full h-1 bg-indigo-500"></div>
            )}
          </button>
        ))}
      </div>

      {/* Content Area */}
      <div className="p-6 md:p-10 animate-in fade-in duration-500">
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-10">
          {/* Resource Links Section (Prominent as requested) */}
          <div className="space-y-6">
            <div>
              <h3 className="text-3xl font-extrabold text-slate-900 mb-2">{activeCourse.fullName}</h3>
              <p className="text-slate-500 font-medium">Click any link below to start learning {activeCourse.title}!</p>
            </div>

            <div className="space-y-3">
              <h4 className="font-bold text-indigo-900 uppercase text-xs tracking-widest flex items-center gap-2 mb-4">
                <i className="fas fa-link text-indigo-500"></i>
                Top Learning Websites
              </h4>
              <div className="grid grid-cols-1 gap-3">
                {activeCourse.resources.map((link, idx) => (
                  <a 
                    key={idx}
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group flex items-center justify-between p-4 bg-slate-50 border border-slate-100 rounded-2xl hover:bg-indigo-50 hover:border-indigo-200 transition-all"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-indigo-500 shadow-sm group-hover:bg-indigo-500 group-hover:text-white transition-all">
                        <i className="fas fa-graduation-cap"></i>
                      </div>
                      <div>
                        <p className="font-bold text-slate-800">{link.label}</p>
                        <p className="text-xs text-slate-400">{link.provider}</p>
                      </div>
                    </div>
                    <i className="fas fa-chevron-right text-slate-300 group-hover:text-indigo-500 transform group-hover:translate-x-1 transition-all"></i>
                  </a>
                ))}
              </div>
            </div>

            <div className="bg-indigo-50/50 p-6 rounded-2xl border border-indigo-100">
              <h4 className="font-bold text-indigo-900 text-sm mb-2">Soli's Tip:</h4>
              <p className="text-indigo-800/80 italic text-sm leading-relaxed">
                "{activeCourse.meaning} Always practice while you learn. Use the playground on the right to see your changes instantly!"
              </p>
            </div>
          </div>

          {/* Playground / Code Section */}
          <div className="space-y-6">
            <div className="bg-slate-900 rounded-2xl overflow-hidden shadow-2xl flex flex-col min-h-[400px]">
              <div className="bg-slate-800 px-5 py-3 flex items-center justify-between border-b border-slate-700">
                <div className="flex gap-2">
                  <div className="w-3 h-3 rounded-full bg-rose-500"></div>
                  <div className="w-3 h-3 rounded-full bg-amber-500"></div>
                  <div className="w-3 h-3 rounded-full bg-emerald-500"></div>
                </div>
                <span className="text-xs text-slate-400 font-mono">practice_{activeCourse.id}.code</span>
              </div>
              
              <div className="flex-1 flex flex-col">
                <div className="flex-1 p-6 text-sm font-mono text-indigo-300 overflow-auto bg-slate-900">
                  <pre><code>{activeCourse.exampleCode}</code></pre>
                </div>
                
                <div className="h-40 bg-white border-t border-slate-200 p-6 overflow-auto">
                   <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-4 border-b border-slate-50 pb-1">
                    Live Output Preview
                  </div>
                  <div 
                    className="w-full h-full"
                    dangerouslySetInnerHTML={{ __html: activeCourse.previewHtml || '' }} 
                  />
                </div>
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
              <h4 className="font-bold text-slate-800 text-sm mb-2 flex items-center gap-2">
                <i className="fas fa-lightbulb text-amber-500"></i>
                Learning Tutorial
              </h4>
              <p className="text-slate-500 text-sm leading-relaxed">
                {activeCourse.tutorial}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CourseExplorer;
