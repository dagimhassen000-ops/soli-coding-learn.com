
import React, { useState } from 'react';
import { Specialization, PaymentMethodType } from '../types';

interface SignUpPageProps {
  onBack: () => void;
  onLogin: () => void;
}

const ETHIOPIAN_BANKS = [
  'Commercial Bank of Ethiopia (CBE)',
  'Dashen Bank',
  'Awash Bank',
  'Bank of Abyssinia',
  'Hibret Bank',
  'Zemen Bank',
  'Enat Bank',
  'Cooperative Bank of Oromia'
];

const SignUpPage: React.FC<SignUpPageProps> = ({ onBack, onLogin }) => {
  const [step, setStep] = useState<'form' | 'payment' | 'success'>('form');
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: '',
    age: '',
    specialization: 'Fullstack' as Specialization
  });
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethodType>('Telebirr');
  const [selectedBank, setSelectedBank] = useState(ETHIOPIAN_BANKS[0]);
  const [loading, setLoading] = useState(false);

  // Price calculation: User requested $1.00 or $0.50. Let's go with $1.00 as the final course price.
  const USD_PRICE = 1.00;
  const ETB_PRICE = 125; // Roughly $1.00 in ETB for local payments

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('payment');
  };

  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Simulate transaction
    setTimeout(() => {
      setLoading(false);
      setStep('success');
    }, 2000);
  };

  if (step === 'success') {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="bg-white w-full max-w-md rounded-[2.5rem] p-12 text-center shadow-2xl animate-in zoom-in duration-300">
          <div className="w-24 h-24 bg-green-100 text-green-600 rounded-full flex items-center justify-center text-5xl mx-auto mb-8 border-4 border-white shadow-lg">
            <i className="fas fa-check"></i>
          </div>
          <h2 className="text-4xl font-extrabold text-indigo-950 mb-4">You're Enrolled!</h2>
          <p className="text-slate-600 text-lg mb-10 leading-relaxed">
            Welcome to the Soli family! Your 75% discount has been applied. Payment received via <span className="font-bold text-indigo-600">{paymentMethod}</span>.
          </p>
          <button 
            onClick={onLogin}
            className="w-full bg-indigo-600 text-white py-5 rounded-2xl font-bold text-xl hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-200"
          >
            Start Learning Now
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="container mx-auto px-4 py-8">
        <button 
          onClick={step === 'payment' ? () => setStep('form') : onBack}
          className="flex items-center gap-2 text-indigo-600 font-bold hover:translate-x-1 transition-transform mb-8"
        >
          <i className="fas fa-arrow-left"></i>
          {step === 'payment' ? 'Back to Registration' : 'Back to Home'}
        </button>

        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-10">
            <div className="inline-block px-4 py-1.5 mb-6 bg-pink-100 text-pink-600 rounded-full font-bold text-sm uppercase tracking-wider animate-pulse shadow-sm">
              🎉 75% Discount Applied
            </div>
            <h1 className="text-4xl font-extrabold text-indigo-950 mb-2">
              {step === 'form' ? 'Enroll in SoliSoft' : 'Secure Checkout'}
            </h1>
            <p className="text-slate-500 font-medium">Join Soli's Software Enjoying course today</p>
          </div>

          <div className="bg-white p-8 md:p-12 rounded-[2.5rem] shadow-2xl shadow-indigo-100/20 border border-slate-100 mb-12">
            {step === 'form' ? (
              <form onSubmit={handleFormSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2 ml-1">Full Name</label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">
                      <i className="fas fa-user"></i>
                    </span>
                    <input 
                      required
                      type="text" 
                      placeholder="Solana Smith"
                      className="w-full pl-12 pr-4 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-inner"
                      value={formData.fullName}
                      onChange={(e) => setFormData({...formData, fullName: e.target.value})}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2 ml-1">Email Address</label>
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">
                        <i className="fas fa-envelope"></i>
                      </span>
                      <input 
                        required
                        type="email" 
                        placeholder="you@email.com"
                        className="w-full pl-12 pr-4 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-inner"
                        value={formData.email}
                        onChange={(e) => setFormData({...formData, email: e.target.value})}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2 ml-1">Age</label>
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">
                        <i className="fas fa-calendar"></i>
                      </span>
                      <input 
                        required
                        type="number" 
                        placeholder="22"
                        className="w-full pl-12 pr-4 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-inner"
                        value={formData.age}
                        onChange={(e) => setFormData({...formData, age: e.target.value})}
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2 ml-1">Password</label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">
                      <i className="fas fa-lock"></i>
                    </span>
                    <input 
                      required
                      type="password" 
                      placeholder="Enter your password"
                      className="w-full pl-12 pr-4 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all shadow-inner"
                      value={formData.password}
                      onChange={(e) => setFormData({...formData, password: e.target.value})}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2 ml-1">Specialization</label>
                  <select 
                    className="w-full px-6 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all appearance-none cursor-pointer"
                    value={formData.specialization}
                    onChange={(e) => setFormData({...formData, specialization: e.target.value as Specialization})}
                  >
                    <option value="Fullstack">Fullstack Development</option>
                    <option value="Backend">Backend Engineering</option>
                    <option value="Frontend">Frontend Design</option>
                    <option value="HTML">HTML Specialist</option>
                    <option value="CSS">CSS Wizardry</option>
                    <option value="JavaScript">JS Ninja</option>
                  </select>
                </div>

                <div className="pt-4">
                  <button 
                    type="submit" 
                    className="w-full bg-indigo-600 text-white py-5 rounded-2xl font-bold text-xl hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100 flex items-center justify-center gap-3"
                  >
                    Proceed to Payment <i className="fas fa-arrow-right text-sm"></i>
                  </button>
                </div>
              </form>
            ) : (
              <form onSubmit={handlePaymentSubmit} className="space-y-8 animate-in slide-in-from-right duration-500">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('Telebirr')}
                    className={`p-4 rounded-2xl border-2 transition-all flex flex-col items-center gap-2 ${paymentMethod === 'Telebirr' ? 'border-indigo-500 bg-indigo-50 shadow-md' : 'border-slate-100 bg-slate-50 hover:bg-white'}`}
                  >
                    <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-sm">
                      <i className="fas fa-mobile-screen-button text-blue-500"></i>
                    </div>
                    <span className="font-bold text-xs text-slate-800">Telebirr</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('EthiopianBank')}
                    className={`p-4 rounded-2xl border-2 transition-all flex flex-col items-center gap-2 ${paymentMethod === 'EthiopianBank' ? 'border-indigo-500 bg-indigo-50 shadow-md' : 'border-slate-100 bg-slate-50 hover:bg-white'}`}
                  >
                    <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-sm">
                      <i className="fas fa-university text-indigo-500"></i>
                    </div>
                    <span className="font-bold text-xs text-slate-800">Eth Bank</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('PayPal')}
                    className={`p-4 rounded-2xl border-2 transition-all flex flex-col items-center gap-2 ${paymentMethod === 'PayPal' ? 'border-indigo-500 bg-indigo-50 shadow-md' : 'border-slate-100 bg-slate-50 hover:bg-white'}`}
                  >
                    <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-sm">
                      <i className="fab fa-paypal text-blue-700"></i>
                    </div>
                    <span className="font-bold text-xs text-slate-800">PayPal</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('MasterCard')}
                    className={`p-4 rounded-2xl border-2 transition-all flex flex-col items-center gap-2 ${paymentMethod === 'MasterCard' ? 'border-indigo-500 bg-indigo-50 shadow-md' : 'border-slate-100 bg-slate-50 hover:bg-white'}`}
                  >
                    <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-sm">
                      <i className="fab fa-cc-mastercard text-red-500"></i>
                    </div>
                    <span className="font-bold text-xs text-slate-800">Card</span>
                  </button>
                </div>

                {paymentMethod === 'EthiopianBank' && (
                  <div className="animate-in fade-in slide-in-from-top duration-300">
                    <label className="block text-sm font-bold text-slate-700 mb-2 ml-1">Select Local Bank</label>
                    <select 
                      className="w-full px-6 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all cursor-pointer"
                      value={selectedBank}
                      onChange={(e) => setSelectedBank(e.target.value)}
                    >
                      {ETHIOPIAN_BANKS.map(bank => (
                        <option key={bank} value={bank}>{bank}</option>
                      ))}
                    </select>
                  </div>
                )}

                <div className="bg-indigo-50 p-6 rounded-3xl border border-indigo-100 flex items-center justify-between">
                  <div>
                    <h4 className="text-indigo-900 font-bold">Course Total</h4>
                    <p className="text-indigo-400 text-xs font-medium">Claiming Soli's 75% Discount</p>
                  </div>
                  <div className="text-right">
                    <div className="text-slate-400 line-through text-sm">ETB 1,200 / $4.00</div>
                    <div className="text-3xl font-extrabold text-indigo-950">
                      {(paymentMethod === 'Telebirr' || paymentMethod === 'EthiopianBank') 
                        ? `ETB ${ETB_PRICE}` 
                        : `$${USD_PRICE.toFixed(2)}`}
                    </div>
                  </div>
                </div>

                <button 
                  type="submit" 
                  disabled={loading}
                  className="w-full bg-indigo-600 text-white py-5 rounded-2xl font-bold text-xl hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100 flex items-center justify-center gap-3 disabled:opacity-70"
                >
                  {loading ? (
                    <>
                      <i className="fas fa-circle-notch fa-spin"></i> Finalizing...
                    </>
                  ) : (
                    <>Pay Now & Enjoy Software</>
                  )}
                </button>
                
                <p className="text-center text-xs text-slate-400 font-medium">
                  <i className="fas fa-shield-halved mr-2"></i> 
                  Secure Payment Gateway for Soli Software
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignUpPage;
