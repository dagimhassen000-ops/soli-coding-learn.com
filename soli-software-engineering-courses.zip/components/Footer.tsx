
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 text-white py-16">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-6">
              <div className="w-10 h-10 bg-indigo-500 rounded-xl flex items-center justify-center text-white text-2xl font-bold">
                S
              </div>
              <span className="text-2xl font-bold tracking-tight">
                Soli<span className="text-indigo-400 font-medium">Software</span>
              </span>
            </div>
            <p className="text-slate-400 max-w-sm mb-6">
              Empowering the next generation of engineers with high-quality, enjoyable software courses. Created by Solana.
            </p>
            <div className="flex gap-4">
              <a 
                href="https://www.instagram.com/solana6924" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center text-xl hover:bg-indigo-600 transition-all"
                title="Follow Soli on Instagram"
              >
                <i className="fab fa-instagram"></i>
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-6">Quick Links</h4>
            <ul className="space-y-4 text-slate-400">
              <li><a href="#" className="hover:text-indigo-400 transition-colors">Home</a></li>
              <li><a href="#courses" className="hover:text-indigo-400 transition-colors">Our Courses</a></li>
              <li><a href="https://www.instagram.com/solana6924" target="_blank" rel="noopener noreferrer" className="hover:text-indigo-400 transition-colors">Contact Support</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-6">Courses</h4>
            <ul className="space-y-4 text-slate-400">
              <li><a href="#" className="hover:text-indigo-400 transition-colors">HTML for Beginners</a></li>
              <li><a href="#" className="hover:text-indigo-400 transition-colors">Advanced CSS Styling</a></li>
              <li><a href="#" className="hover:text-indigo-400 transition-colors">Modern JavaScript</a></li>
              <li><a href="#" className="hover:text-indigo-400 transition-colors">Python Masterclass</a></li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-slate-500">
          <p>© {new Date().getFullYear()} Soli Software Enjoying Course. All rights reserved.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-slate-300">Privacy Policy</a>
            <a href="#" className="hover:text-slate-300">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
